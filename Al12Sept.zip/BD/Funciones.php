<?php
    Function AgregarEspacios(&$texto){
        $texto=$texto."&nbsp;";
        //return $texto;
    }
    Function AgregarEspacios2(&$texto){
        $texto=$texto." ";
        //return $texto;
    }
    Function AgregarCeros(&$texto){
        $texto=$texto."0";
        //return $texto;
    }
    Function LargoString($String){
        return strlen ($String);
    }
    Function CompletarCaracteristica (&$Caracteristica){
        $largo=strlen($Caracteristica);
        switch ($largo) {
            case 0 : 
                $Caracteristica= "00000";
                break;
            case 1 :
                $Caracteristica="0000".$Caracteristica;
                break;
            case 2 :
                $Caracteristica="000".$Caracteristica;
                break;
            case 3 :
                $Caracteristica="00".$Caracteristica;
                break;
            case 4 :
                $Caracteristica="0".$Caracteristica;
                break;
        }
    }
    Function CompletarNumeroTelefono(&$NumeroTelefono){
        $largo=strlen($NumeroTelefono);
        switch ($largo) {
            case 0 :
                $NumeroTelefono="00000000";
                break;
            case 1 : 
                $NumeroTelefono="0000000".$NumeroTelefono;
                break;
            case 2 : 
                $NumeroTelefono="000000".$NumeroTelefono;
                break;
            case 3 : 
                $NumeroTelefono="00000".$NumeroTelefono;
                break;
            case 4 :
                $NumeroTelefono="0000".$NumeroTelefono;
                break;
            case 5 :
                $NumeroTelefono="000".$NumeroTelefono;
                break;
            case 6 :
                $NumeroTelefono="00".$NumeroTelefono;
                break;
            case 7 :
                $NumeroTelefono="0".$NumeroTelefono;
                break;
        }
    }
    Function CompletarFechaNacimiento(&$NumeroTelefono){
        $largo=strlen($NumeroTelefono);
        switch ($largo) {
            case 0 :
                $NumeroTelefono="00000000";
                break;
            case 1 : 
                $NumeroTelefono="0000000".$NumeroTelefono;
                break;
            case 2 : 
                $NumeroTelefono="000000".$NumeroTelefono;
                break;
            case 3 : 
                $NumeroTelefono="00000".$NumeroTelefono;
                break;
            case 4 :
                $NumeroTelefono="0000".$NumeroTelefono;
                break;
            case 5 :
                $NumeroTelefono="000".$NumeroTelefono;
                break;
            case 6 :
                $NumeroTelefono="00".$NumeroTelefono;
                break;
            case 7 :
                $NumeroTelefono="0".$NumeroTelefono;
                break;
        }
    }
    Function CompletarTipoDocumento (&$TipoDocumento){
        $largo=strlen($TipoDocumento);
        switch ($largo) {
            case 0 : 
                $TipoDocumento= "00";
                break;
            case 1 :
                $TipoDocumento="0".$TipoDocumento;
                break;
        }
    }
    Function CompletarDocumentoProvincia (&$DocumentoProvincia){
        $largo=strlen($DocumentoProvincia);
        switch ($largo) {
            case 0 : 
                $DocumentoProvincia= "00";
                break;
            case 1 :
                $DocumentoProvincia="0".$DocumentoProvincia;
                break;
        }
    }
    Function CompletarNumeroDocumento(&$NumeroDocumento){
        $largo=strlen($NumeroDocumento);
        switch ($largo) {
            case 0 :
                $NumeroDocumento="00000000000";
                break;
            case 2 :
                $NumeroDocumento="0000000000".$NumeroDocumento;
                break;
            case 3 :
                $NumeroDocumento="00000000".$NumeroDocumento;
                break;
            case 4 :
                $NumeroDocumento="0000000".$NumeroDocumento;
                break;
            case 5 :
                $NumeroDocumento="000000".$NumeroDocumento;
                break;
            case 6 :
                $NumeroDocumento="00000".$NumeroDocumento;
                break;
            case 7 :
                $NumeroDocumento="0000".$NumeroDocumento;
                break;
            case 8 :
                $NumeroDocumento="000".$NumeroDocumento;
                break;
            case 9 :
                $NumeroDocumento="00".$NumeroDocumento;
                break;
            case 10 :
                $NumeroDocumento="00".$NumeroDocumento;
                break;
        }
    }
    Function CompletarCUIT(&$Cuit) {
        $largo = strlen($Cuit);
        switch ($largo) {
            case 0 :
                $Cuit="00000000000";
                break;
            case 1 :
                $Cuit="0000000000".$Cuit;
                break;
            case 2 :
                $Cuit="000000000".$Cuit;
                break;
            case 3 :
                $Cuit="00000000".$Cuit;
                break;
            case 4 :
                $Cuit ="0000000".$Cuit;
            case 5 :
                $Cuit="000000".$Cuit;
                break;
            case 6 :
                $Cuit ="00000".$Cuit;
                break;
            case 7 :
                $Cuit="0000".$Cuit;
                break;
            case 8 :
                $Cuit="000".$Cuit;
                break;
            case 9 :
                $Cuit="00".$Cuit;
                break;
            case 10 :
                $Cuit="0".$Cuit;
                break;
        }
    }
    function validar_cuit_cuil($cuit_cuil) {
        // Eliminar caracteres no numéricos
        $cuit_cuil = preg_replace('/\D/', '', $cuit_cuil);
      
        // Validar longitud
        if (strlen($cuit_cuil) != 11) {
          return false;
        }
      
        // Validar número verificador
        $acumulado = 0;
        $coeficientes = array(5, 4, 3, 2, 7, 6, 5, 4, 3, 2);
        for ($i = 0; $i < 10; $i++) {
          $acumulado += $coeficientes[$i] * intval(substr($cuit_cuil, $i, 1));
        }
        $resto = $acumulado % 11;
        $digito_verificador = ($resto == 0) ? 0 : (($resto == 1) ? 9 : (11 - $resto));
        return intval(substr($cuit_cuil, 10, 1)) == $digito_verificador;
      }
      function formatearNumero($numero) {
        $numeroFormateado = sprintf("%010.2f", $numero);
        $numeroFormateado = str_replace('.', '', $numeroFormateado);

        return $numeroFormateado;
    }
    function formatearNumeroSumatoria($numero) {
        // $numeroFormateado = sprintf("%011.2f", $numero);
        // $numeroFormateado = str_replace('.', '', $numeroFormateado);

        // return $numeroFormateado;
        return $numero;
    }
    function guardarArrayEnArchivo($array, $rutaArchivo) {
        // Convierte el array a formato JSON
        $contenido = json_encode($array);
    
        // Abre el archivo en modo de escritura
        $archivo = fopen($rutaArchivo, 'w');
    
        if ($archivo) {
            // Escribe el contenido JSON en el archivo
            fwrite($archivo, $contenido);
            
            // Cierra el archivo
            fclose($archivo);
            
            return true; // Éxito en la escritura
        } else {
            return false; // No se pudo abrir el archivo
        }
    }
    function guardarArrayEnArchivoConSaltos($array, $rutaArchivo) {
        // Convierte el array a formato JSON con saltos de línea
        $contenido = json_encode($array, JSON_PRETTY_PRINT);
    
        // Abre el archivo en modo de escritura
        $archivo = fopen($rutaArchivo, 'w');
    
        if ($archivo) {
            // Escribe el contenido JSON en el archivo
            fwrite($archivo, $contenido);
            
            // Cierra el archivo
            fclose($archivo);
            
            return true; // Éxito en la escritura
        } else {
            return false; // No se pudo abrir el archivo
        }
    }

    function escribirArrayEnArchivo($array, $nombreArchivo) {
        // Abre el archivo en modo de escritura
        $archivo = fopen($nombreArchivo, "w");
      
        // Recorre el array
        foreach ($array as $valor) {
          // Escribe el valor en el archivo con un salto de línea
          fwrite($archivo, $valor . PHP_EOL);
        }
      
        // Cierra el archivo
        fclose($archivo);
      }
      
      
    
    
?>