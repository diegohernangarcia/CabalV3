<?php
    Function CantidadRegistrosBD($BD){
        //require_once('UsarGestion.php');
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql = 'SELECT * FROM '.$BD;
        $cantidad=0;        
        foreach ($conn->query($sql) as $row) {
            $cantidad++;
        }
        return $cantidad;
    }
    Function TruncateTable ($BD){
       // require_once('UsarGestion.php');
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql="TRUNCATE TABLE ".$BD;
        $statement = $conn->prepare($sql);
        $statement->execute();
    }
    Function EstaDNI ($DNI){
        require_once("BD/Funciones.php");
        CompletarNumeroDocumento($DNI);
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sentencia = $conn->prepare("SELECT id FROM beneficiario WHERE NumeroDocumento = ? LIMIT 1;");
        $sentencia->execute([$DNI]);
        # Ver cuántas filas devuelve
        $numeroDeFilas = $sentencia->rowCount();
        # Si son 0 o menos, significa que no existe
        if ($numeroDeFilas <= 0) {
        //echo "El usuario con DNI $DNI NO existe";
        return false;
          } else {
               //echo "El usuario con DNI $DNI SÍ existe";
               return true;
        }
    }
    Function DevuelvoIdBeneficiario ($DNI){
        require_once("BD/Funciones.php");
        //CompletarNumeroDocumento($DNI);
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql="SELECT id FROM beneficiario WHERE NumeroDocumento = $DNI LIMIT 1;";
       // echo $sql."<br>";
        foreach ($conn->query($sql) as $row) {
            return $row['id'];
        }
    }
    Function EstaFecha ($Mes,$Anio){
        require_once("BD/Funciones.php");
        CompletarNumeroDocumento($DNI);
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sentencia = $conn->prepare("SELECT id FROM Movimientos WHERE Mes='".$Mes. "' AND Anio='".$Anio."';");
        //echo "SELECT id FROM Movimientos WHERE Mes='".$Mes. "' AND Anio='".$Anio."';";die();
        $sentencia->execute([$DNI]);
        # Ver cuántas filas devuelve
        $numeroDeFilas = $sentencia->rowCount();
        # Si son 0 o menos, significa que no existe
        if ($numeroDeFilas <= 0) {
        //echo "El usuario con DNI $DNI NO existe";
        return false;
          } else {
               //echo "El usuario con DNI $DNI SÍ existe";
               return true;
        }
    }
    Function DevuelvoNumeroCuenta ($DNI,$CUIT){
        require_once("BD/Funciones.php");
        //CompletarNumeroDocumento($DNI);
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql="SELECT NumeroCuenta FROM beneficiario WHERE NumeroDocumento =$DNI and Cuit=$CUIT;";
        //echo $sql;die();
        foreach ($conn->query($sql) as $row) {
                return $row['NumeroCuenta'];
            }
        
    }    
    Function EstaBienCuenta ($Nombre,$Apellido,$Cuenta){
        require_once("BD/Funciones.php");
        //CompletarNumeroDocumento($DNI);
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql="SELECT id FROM beneficiario WHERE Apellido='$Apellido' AND Nombre='$Nombre' AND NumeroCuenta=$Cuenta;";
        
        //echo $sql;//
        foreach ($conn->query($sql) as $row) {
                return $row['id'];
            }
    }
    Function DevuelvoDatosCuenta ($DNI){
        require_once("BD/Funciones.php");
        $datos=[];
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql="SELECT * FROM beneficiario WHERE NumeroDocumento =$DNI;";
        //echo $sql;die();
        $datos[0]=0;

        foreach ($conn->query($sql) as $row) {
                $datos[0]=$row['id'];
                $datos[1]=$row['Apellido'];
                $datos[2]=$row['Nombre'];
                $datos[3]=$row['Calle'];
                $datos[4]=$row['Numero'];
                $datos[5]=$row['Piso'];
                $datos[6]=$row['Departamento'];
                $datos[7]=$row['Localidad'];
                $datos[8]=$row['Provincia'];
                $datos[9]=$row['Sexo'];
                $datos[10]=$row['NumeroCuenta'];
                $datos[11]=$row['NumeroTarjeta'];
                $datos[12]=$row['FechaNacimiento'];
                $datos[13]=$row['TipoDocumento'];
                $datos[14]=$row['NumeroDocumento'];
                $datos[15]=$row['Cuit'];
            }
        return $datos;
        
    }    
    Function DevuelvoApellidoNombrePorDNI ($DNI){
        require_once("BD/Funciones.php");
        $datos=[];
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql="SELECT * FROM beneficiario WHERE NumeroDocumento =$DNI;";
        //echo $sql;die();
        $datos[0]=0;

        foreach ($conn->query($sql) as $row) {
                $datos[1]=trim($row['Apellido']);
                $datos[2]=trim($row['Nombre'])  ;
                
            }
        return $datos;
        
    }   
    Function DevuelvoApellidoyNombrePorNumeroCuenta ($NroCuenta){
        require_once("BD/Funciones.php");
        $conn = new PDO('mysql:host=localhost;dbname=cabal','root','');
        $sql="SELECT * FROM beneficiario WHERE NumeroCuenta =$NroCuenta;";
  //      echo $sql."<br>";
        
        $Quien="SIN DATOS";
        foreach ($conn->query($sql) as $row) {
                $Quien= $row['Apellido']." ".$row['Nombre'];
                //echo $Quien;
            }
        return $Quien;
        
    }     
?>